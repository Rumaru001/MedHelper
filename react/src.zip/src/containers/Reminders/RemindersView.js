import React from "react";
import Base from "../../components/Main/Base";
import Button from "react-bootstrap/Button";

export default class Reminders extends React.Component {

  render() {
    return(
        <div><h1>Reminders PAGE</h1></div>
    );

  }
}